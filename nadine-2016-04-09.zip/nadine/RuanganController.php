<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Ruangan;

use App\Jadwal;

use DB;

class RuanganController extends Controller
{
    public function listRuangan()
    {
    	// get list ruangan pada database
    	$allruangan = Ruangan::all()->where('deleted',0);
        $alljadwal = Jadwal::all();

    	// return listruangan
    	return view('ruangan', compact('allruangan','alljadwal'));
    }

    public function listJadwal()
    {
    	$results1 = DB::select(DB::raw("SELECT * FROM jadwal j, ruangan r WHERE j.IdRuangan = r.IdRuangan"));

    	

    	// render view list jadwal ruangan
    	return view('ruangan', compact('results1'));
    }

    public function updateRuangan()
    {
    	// get session ruangan yang dipilih untuk diupdate

    	// ubah database

    	// return notifikasi

    }

    public function removeRuangan(Request $request)
    {
    	//get session
        $input = $request->all();
        $inputs = $input['Id'];

        //ganti status
        DB::update(DB::raw("UPDATE Ruangan SET deleted = 1 WHERE IdRuangan = $inputs"));

        return 'Succesful';
    }

    public function createRuangan()
    {

    }

}
