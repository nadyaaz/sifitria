@extends('master')

@section('user-role')
    Jundi Ahmad Alwan (Manajer Fasilitas & Infrastruktur)
@stop

@section('modul')
	Peminjaman Ruangan
@stop

@section('title')
	Ruangan
@stop

@section('sidebar1')
	Dashboard
@stop

@section('sidebar2')
	List Ruangan
@stop

@section('sidebar2_active')
	active
@stop

@section('tableTitle')
	List Ruangan
@stop

@section('thead1')
	No Ruangan
@stop

@section('thead2')
	Gedung
@stop

@section('thead3')
	Jenis Ruangan
@stop

@section('thead4')
	Kapasitas
@stop

@section('thead5')
	<p></p>
@stop

@section('konten')
<div class="subsection">
    <h6>@yield('tableTitle')</h6>
        <div class="divider"></div>
        <br>
        <div class="row">
        <div class="col s12">
            <ul class="tabs">
              <li class="tab col s2"><a class="active"href="#test1">Gedung G</a></li>
              <li class="tab col s2"><a href="#test2">Gedung M</a></li>
            </ul>
        </div>

      
       <div id="test1" class="col s12">
		        	<div id="tableHead" class="row">
                  	<div class="col s2">@yield('thead1')</div>
                    <div class="col s2">@yield('thead2')</div>
                    <div class="col s2">@yield('thead3')</div>
                    <div class="col s2">@yield('thead4')</div>
              </div>
                    <ul class="collapsible" data-collapsible="accordion">
                    @foreach($allruangan as $ruangan)
                    @if($ruangan->Gedung == 'A' )
                    <li>
                        <div class="collapsible-header">
                            <div id="tableRow" class="row">
                              <div class="col s2"> {{ $ruangan->IdRuangan }} </div>
                              <div class="col s2"> {{ $ruangan->Gedung }} </div>
                              <div class="col s2"> {{ $ruangan-> NomorRuangan }} </div>
                              <div class="col s2"> {{ $ruangan-> KapasitasRuangan }} </div>
                                  <div class="col s1">
                                    <a href=""  class="tooltipped white-text waves-effect waves-light btn-flat" data-position="bottom" data-delay="10" data-tooltip="Edit Ruangan" >
                                    <i id="edit-button"class="tiny material-icons">edit</i>
                                    <p>
                                    </p>
                                    </a>
                              </div>
                              <div class="col s2">
                                  <form action="{{ url('ruangan/hapus') }}" method="POST">
                                    <div class="col s1">
                                      {!! csrf_field() !!}
                                      <input type="hidden" name="Id" value="{{ $ruangan->IdRuangan}}"/>
                                      <button id="cancel-button" class="tooltipped white-text waves-effect waves-light btn-flat" data-position="bottom" data-delay="10" data-tooltip="Hapus Ruangan" >
                                      <i id="edit-button" class="tiny material-icons">cancel</i>
                                      </button>

                                    </div>
                                  </form>

                              </div>
                            </div>
                        </div>

                        <div class="collapsible-body">
                            <div class = "row">
                                <div class="col s6">
                                    @foreach($alljadwal as $jadwal)
                                    @if($ruangan->IdRuangan == $jadwal->IdRuangan )
                                    Jadwal :<br>
                                    {{ $jadwal->WaktuMulai }} -
                                    {{ $jadwal->WaktuSelesai}} </br>
                                    @endif
                                    @endforeach
                                </div>
                            </div> 
                        </div>
                     
                    </li>
                    @endif
                    @endforeach

         
                    </ul>
             </div>

          </div>
      </div>
         <div id="test2" class="col s12">
              <div id="tableHead" class="row">
                    <div class="col s2">@yield('thead1')</div>
                    <div class="col s2">@yield('thead2')</div>
                    <div class="col s2">@yield('thead3')</div>
                    <div class="col s2">@yield('thead4')</div>
                </div>
                    <ul class="collapsible" data-collapsible="accordion">
                    @foreach($allruangan as $ruangan)
                     @if($ruangan->Gedung == 'B' )
                    <li>
                  <div class="collapsible-header">
                            <div id="tableRow" class="row">
                              <div class="col s2"> {{ $ruangan->IdRuangan }} </div>
                              <div class="col s2"> {{ $ruangan->Gedung }} </div>
                              <div class="col s2"> {{ $ruangan-> NomorRuangan }} </div>
                              <div class="col s2"> {{ $ruangan-> KapasitasRuangan }} </div>
                                  <div class="col s1">
                                      <a href=""  class="tooltipped white-text waves-effect waves-light btn-flat" data-position="bottom" data-delay="10" data-tooltip="Edit Ruangan" >
                                      <i id="edit-button"class="tiny material-icons">edit</i>
                                      <p>
                                      </p>
                                      </a>
                                  </div>
                              <div class="col s2">
                                  <form action="{{ url('ruangan/hapus') }}" method="POST">
                                      <div class="col s1">
                                        {!! csrf_field() !!}
                                        <input type="hidden" name="Id" value="{{ $ruangan->IdRuangan}}"/>
                                        <button id="cancel-button" class="tooltipped white-text waves-effect waves-light btn-flat" data-position="bottom" data-delay="10" data-tooltip="Hapus Ruangan" >
                                          <i id="edit-button" class="tiny material-icons">cancel</i>
                                        </button>
                                      </div>
                                  </form>
                              </div>
                          </div>
                 </div>

                        <div class="collapsible-body">
                            <div class = "row">
                                <div class="col s6">
                                    @foreach($alljadwal as $jadwal)
                                    @if($ruangan->IdRuangan == $jadwal->IdRuangan )
                                    Jadwal :<br>
                                    {{ $jadwal->WaktuMulai }} -
                                    {{ $jadwal->WaktuSelesai}} </br>
                                    @endif
                                    @endforeach
                                </div>
                            </div> 
                        </div>
                    
                    </li>
                      @endif
                     @endforeach
                    </ul>
             </div>
          </div>
      </div>
                    
       @stop                 


                       